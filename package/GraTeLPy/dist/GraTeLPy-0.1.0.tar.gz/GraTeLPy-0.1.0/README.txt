========
GraTeLPy
========

GratTeLPy (Graph Theoretic Analysis of Linear Stability) is a software tool for parameter-free, graph-theoretic linear stability analysis. Given a mechanism file that determines a system of reactions, it analyses SOMETHING and 

Typical usage looks like this::





